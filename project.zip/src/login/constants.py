"""Module for defining login-level constants."""

EXC_MSG_LOGIN_FAILED = "Login failed. Please check your credentials."
